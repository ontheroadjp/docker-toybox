<?php

###
# @name			Configuration
# @author		Tobias Reich
# @copyright	2015 Tobias Reich
###

if(!defined('LYCHEE')) exit('Error: Direct access is not allowed!');

# Database configuration
$dbHost = '172.17.3.107'; # Host of the database
$dbUser = 'lychee'; # Username of the database
$dbPassword = 'lychee'; # Password of the database
$dbName = 'lychee'; # Database name
$dbTablePrefix = ''; # Table prefix

?>